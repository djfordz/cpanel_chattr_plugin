<?php

require_once '/usr/local/cpanel/php/cpanel.php';
require_once 'Chattr.php';
require_once 'chattr.css';

$cpanel = new CPANEL();

$chattr = new Nemj_Chattr($cpanel);

print $cpanel->header("File Lock", "nemj-chattr");

$get_userdata = $cpanel->uapi(
    'DomainInfo', 'domains_data',
    array(
        'format' => 'hash',
    )
);

$chattr->listFiles();

?>
<?php
print $cpanel->footer();
$cpanel->end();
?>

