<?php

class Chattr
{
    protected $cpanel;

    protected $userPath;

    public function __construct($cpanel)
    {
        $this->cpanel = $cpanel;
        $processUser = posix_getpwuid(posix_geteuid());
        $user = $processUser['name'];
        $this->userPath = "/home/$user/";
    }

    public function listFiles()
    {
        return $this->cpanel->uapi(
            'Fileman', 'list_files',
            array(
                'dir'                           => $this->userPath,
                'types'                         => 'dir|file',
                'limit_to_list'                 => '0',
                'show_hidden'                   => '1',
                'check_for_leaf_directories'    => '1',
                'include_mime'                  => '0',
                'include_hash'                  => '0',
                'include_permissions'           => '1'
            )
        );
    }
}
